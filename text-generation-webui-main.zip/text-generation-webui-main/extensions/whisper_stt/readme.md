# whisper_stt

Allows you to enter your inputs in chat mode using your microphone.

## Settings

To adjust your default settings, you can add the following to your settings.yaml file.

```
whisper_stt-whipser_language: chinese
whisper_stt-whipser_model: tiny
whisper_stt-auto_submit: False
```

See source documentation for [model names](https://github.com/openai/whisper#available-models-and-languages) and [languages](https://github.com/openai/whisper/blob/main/whisper/tokenizer.py) you can use.
