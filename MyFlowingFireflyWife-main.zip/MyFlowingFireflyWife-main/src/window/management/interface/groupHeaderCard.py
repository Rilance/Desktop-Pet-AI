from qfluentwidgets import (
    GroupHeaderCardWidget
)


class SettinsCard(GroupHeaderCardWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

